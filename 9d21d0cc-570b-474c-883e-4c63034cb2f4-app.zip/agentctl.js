#!/usr/bin/env node
"use strict";

// src/agentctl.ts
var import_node_child_process5 = require("node:child_process");
var import_node_fs7 = require("node:fs");
var import_node_path6 = require("node:path");

// ../shared/src/contract.ts
var INSTRUCTIONS_VERSION = 3;
var INSTRUCTIONS_UPDATED = "2026-10-26";
var AGENT_KINDS = ["claude-code", "openclaw", "service", "other"];
var REPORTED_STATES = ["working", "waiting", "idle", "stopped", "failed"];
var WORK_TYPES = [
  "feature",
  "bugfix",
  "testing",
  "refactor",
  "infra",
  "docs",
  "level-design",
  "game-design",
  "writing",
  "art",
  "community",
  "planning",
  "other"
];
var LIMITS = {
  reportBytes: 64 * 1024,
  logsBytes: 1024 * 1024,
  logsPerCall: 500,
  heartbeatAgents: 500,
  idLength: 200,
  nameLength: 120,
  activityLength: 500,
  storyLength: 300,
  taskLength: 300,
  promptLength: 2e3,
  resultTitleLength: 200,
  resultSummaryLength: 8e3,
  resultChecks: 12,
  resultCheckLength: 300,
  messageLength: 8e3,
  /** A message the owner sends to an agent from the UI. */
  agentMessageLength: 4e3,
  linkLength: 2e3,
  /** Models in one report's token usage. */
  usageModels: 10,
  perfBytes: 512 * 1024,
  perfSamplesPerCall: 500,
  /** Custom numbers on one performance sample. */
  perfMetrics: 32,
  perfMetricNameLength: 60,
  /** Single slow frames in one call, and the worst of them kept on a session. */
  perfHitchesPerCall: 200,
  perfHitchesKept: 50,
  /** A blocker's one-line description, and the longer one. */
  blockerTitleLength: 200,
  blockerDetailsLength: 8e3,
  /** The owner's answer to a blocker. */
  blockerResolutionLength: 4e3,
  /** Screenshots and videos on one blocker. */
  blockerMedia: 6,
  blockerImageBytes: 8 * 1024 * 1024,
  blockerVideoBytes: 25 * 1024 * 1024
};
var BLOCKER_MEDIA_TYPES = {
  "image/png": "image",
  "image/jpeg": "image",
  "image/webp": "image",
  "image/gif": "image",
  "video/mp4": "video",
  "video/webm": "video"
};

// ../shared/src/validate.ts
var KIND_HINT = `kind must be one of ${AGENT_KINDS.join(", ")}`;
var MAX_T = 30 * 86400;

// ../shared/src/perf.ts
var PERF_BOUNDS = ["cpu", "game", "render", "gpu"];
function perfStats(t) {
  const mean = (w) => w && w.frames > 0 ? w.sum / w.frames : null;
  const parts = PERF_BOUNDS.map((name) => ({ name, ms: mean(t[`${name}Ms`]) })).filter((p) => p.ms !== null);
  const bound = parts.length >= 2 ? parts.reduce((a, b) => b.ms > a.ms ? b : a).name : null;
  return {
    samples: t.samples,
    seconds: t.seconds,
    frames: t.frames,
    avgFps: t.seconds > 0 ? t.frames / t.seconds : null,
    frameMsAvg: t.frames > 0 ? t.seconds * 1e3 / t.frames : null,
    frameMsP50: mean(t.frameMsP50),
    frameMsP95: mean(t.frameMsP95),
    frameMsP99: mean(t.frameMsP99),
    frameMsMax: t.frameMsMax,
    hitches: t.hitches,
    hitchesPerMinute: t.seconds > 0 ? t.hitches / t.seconds * 60 : null,
    cpuMs: mean(t.cpuMs),
    gameMs: mean(t.gameMs),
    renderMs: mean(t.renderMs),
    gpuMs: mean(t.gpuMs),
    bound,
    memoryMbMax: t.memoryMbMax,
    vramMbMax: t.vramMbMax
  };
}

// src/blocker.ts
var import_node_child_process = require("node:child_process");
var import_node_fs = require("node:fs");
var import_node_os = require("node:os");
var import_node_path = require("node:path");
var BY_EXTENSION = {
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".gif": "image/gif",
  ".mp4": "video/mp4",
  ".m4v": "video/mp4",
  ".webm": "video/webm"
};
var BlockerFileError = class extends Error {
};
function readBlockerFile(path) {
  if (!(0, import_node_fs.existsSync)(path) || !(0, import_node_fs.statSync)(path).isFile()) throw new BlockerFileError(`No file at ${path}`);
  const contentType = BY_EXTENSION[(0, import_node_path.extname)(path).toLowerCase()];
  if (!contentType) {
    throw new BlockerFileError(`${(0, import_node_path.basename)(path)}: send a PNG, JPEG, WebP or GIF screenshot, or an MP4 or WebM video`);
  }
  const size = (0, import_node_fs.statSync)(path).size;
  const max = BLOCKER_MEDIA_TYPES[contentType] === "image" ? LIMITS.blockerImageBytes : LIMITS.blockerVideoBytes;
  if (size > max) {
    throw new BlockerFileError(`${(0, import_node_path.basename)(path)} is ${(size / 1024 / 1024).toFixed(1)} MB; the limit is ${max / 1024 / 1024} MB. Shrink or trim it.`);
  }
  return { path, name: (0, import_node_path.basename)(path), contentType, bytes: (0, import_node_fs.readFileSync)(path) };
}
function captureScreen() {
  if (process.platform === "win32") {
    throw new BlockerFileError(
      "--screen doesn't work on Windows (Defender blocks scripted screen captures). Attach a screenshot you have instead: --screenshot <file>"
    );
  }
  const path = (0, import_node_path.join)((0, import_node_os.tmpdir)(), `agent-manager-delux-screen-${Date.now()}.jpg`);
  try {
    if (process.platform === "darwin") {
      (0, import_node_child_process.execFileSync)("screencapture", ["-x", "-t", "jpg", path], { stdio: ["ignore", "ignore", "pipe"], timeout: 3e4 });
    } else {
      captureLinux(path);
    }
  } catch (e) {
    const detail = e.stderr?.toString().trim().split("\n").pop() || e.message;
    throw new BlockerFileError(`Couldn't capture the screen: ${detail}`);
  }
  if (!(0, import_node_fs.existsSync)(path)) throw new BlockerFileError("Couldn't capture the screen: no image was written");
  try {
    return { ...readBlockerFile(path), name: "screen.jpg" };
  } finally {
    (0, import_node_fs.rmSync)(path, { force: true });
  }
}
function captureLinux(path) {
  const tools = [
    ["gnome-screenshot", ["-f", path]],
    ["grim", [path]],
    ["import", ["-window", "root", path]],
    ["scrot", ["-o", path]]
  ];
  for (const [tool, args] of tools) {
    try {
      (0, import_node_child_process.execFileSync)(tool, args, { stdio: ["ignore", "ignore", "pipe"], timeout: 3e4 });
      return;
    } catch (e) {
      if (e.code !== "ENOENT") throw e;
    }
  }
  throw new Error("no screenshot tool found (gnome-screenshot, grim, ImageMagick import or scrot); pass --screenshot <file> instead");
}
function describeBlocker(b) {
  if (b.status === "open") {
    return `Blocker ${b.id} is still open: "${b.title}". The person hasn't answered yet.`;
  }
  const verb = b.status === "resolved" ? "resolved" : "dismissed";
  const lines = [`Blocker ${b.id} was ${verb} by ${b.resolvedBy ?? "the person"} at ${b.resolvedAt}: "${b.title}".`];
  if (b.status === "dismissed") lines.push("They won't act on it: carry on without it, or stop and say why you can't.");
  lines.push(b.resolution ? `Their answer:
${b.resolution}` : "They left no note.");
  return lines.join("\n");
}

// src/config.ts
var import_node_os3 = require("node:os");

// src/files.ts
var import_node_fs2 = require("node:fs");
var import_node_path3 = require("node:path");

// src/paths.ts
var import_node_os2 = require("node:os");
var import_node_path2 = require("node:path");
function home() {
  return process.env.AGENT_MANAGER_HOME || (0, import_node_path2.join)((0, import_node_os2.homedir)(), ".agent-manager");
}
var paths = {
  config: () => (0, import_node_path2.join)(home(), "config.json"),
  script: () => (0, import_node_path2.join)(home(), "agentctl.js"),
  sessions: () => (0, import_node_path2.join)(home(), "sessions"),
  daemon: () => (0, import_node_path2.join)(home(), "daemon.json"),
  log: () => (0, import_node_path2.join)(home(), "reporter.log"),
  claudeSettings: () => process.env.CLAUDE_SETTINGS_PATH || (0, import_node_path2.join)((0, import_node_os2.homedir)(), ".claude", "settings.json")
};

// src/files.ts
function readJsonFile(file) {
  try {
    return JSON.parse((0, import_node_fs2.readFileSync)(file, "utf8"));
  } catch {
    return null;
  }
}
function writeJsonFile(file, value) {
  (0, import_node_fs2.mkdirSync)((0, import_node_path3.dirname)(file), { recursive: true });
  const tmp = `${file}.${process.pid}.tmp`;
  (0, import_node_fs2.writeFileSync)(tmp, JSON.stringify(value, null, 2));
  (0, import_node_fs2.renameSync)(tmp, file);
}
var LOG_MAX_BYTES = 1024 * 1024;
function logLine(message) {
  try {
    const file = paths.log();
    (0, import_node_fs2.mkdirSync)((0, import_node_path3.dirname)(file), { recursive: true });
    if ((0, import_node_fs2.existsSync)(file) && (0, import_node_fs2.statSync)(file).size > LOG_MAX_BYTES) (0, import_node_fs2.renameSync)(file, `${file}.1`);
    (0, import_node_fs2.appendFileSync)(file, `${(/* @__PURE__ */ new Date()).toISOString()} [${process.pid}] ${message}
`);
  } catch {
  }
}

// src/config.ts
var ConfigError = class extends Error {
};
function defaultMachineName() {
  return (0, import_node_os3.hostname)().toLowerCase();
}
function loadConfig() {
  const saved = readJsonFile(paths.config()) ?? {};
  const url = (process.env.AGENT_MANAGER_URL || saved.url || "").replace(/\/+$/, "");
  const key = process.env.AGENT_MANAGER_KEY || saved.key || "";
  if (!url) throw new ConfigError(`No Agent Manager Delux URL: run "agentctl install --url <url>" (config: ${paths.config()})`);
  if (!key) throw new ConfigError('No machine key: set AGENT_MANAGER_KEY or run "agentctl install"');
  return {
    url,
    key,
    machine: saved.machine || defaultMachineName(),
    ...saved.prompts === false ? { prompts: false } : {},
    ...saved.messages === true ? { messages: true } : {}
  };
}

// src/daemon.ts
var import_node_child_process3 = require("node:child_process");
var import_node_fs5 = require("node:fs");

// src/transcript.ts
var import_node_fs3 = require("node:fs");
var TAIL_BYTES = 512 * 1024;
var NARRATION_MAX = 200;
var NO_TRANSCRIPT = { title: null, narration: null };
function readTranscript(file) {
  if (!file) return NO_TRANSCRIPT;
  try {
    return parseTranscript(readTail(file, TAIL_BYTES));
  } catch {
    return NO_TRANSCRIPT;
  }
}
function readTail(file, bytes) {
  const fd = (0, import_node_fs3.openSync)(file, "r");
  try {
    const size = (0, import_node_fs3.fstatSync)(fd).size;
    const start = Math.max(0, size - bytes);
    const buf = Buffer.alloc(size - start);
    (0, import_node_fs3.readSync)(fd, buf, 0, buf.length, start);
    const text2 = buf.toString("utf8");
    return start > 0 ? text2.slice(text2.indexOf("\n") + 1) : text2;
  } finally {
    (0, import_node_fs3.closeSync)(fd);
  }
}
function parse(line) {
  try {
    return JSON.parse(line);
  } catch {
    return null;
  }
}
function isPrompt(line) {
  if (line.type !== "user" || line.isMeta || line.isSidechain) return false;
  const content = line.message?.content;
  if (typeof content === "string") return true;
  return Array.isArray(content) && content.some((c) => c?.type === "text");
}
function assistantText(line) {
  if (line.type !== "assistant" || line.isSidechain) return null;
  const content = line.message?.content;
  if (!Array.isArray(content)) return null;
  for (const c of content) {
    if (c?.type === "text" && typeof c.text === "string" && c.text.trim()) return c.text;
  }
  return null;
}
function parseTranscript(text2) {
  const lines = text2.split("\n");
  let customTitle = null;
  let aiTitle = null;
  let narration = null;
  let turnStarted = false;
  for (let i = lines.length - 1; i >= 0; i--) {
    const raw = lines[i];
    if (!raw) continue;
    if (!customTitle && raw.includes('"custom-title"')) {
      customTitle = parse(raw)?.customTitle?.trim() || null;
    } else if (!aiTitle && raw.includes('"ai-title"')) {
      aiTitle = parse(raw)?.aiTitle?.trim() || null;
    } else if (!narration && !turnStarted && raw.includes('"assistant"') && raw.includes('"text"')) {
      const line = parse(raw);
      const said = line && assistantText(line);
      if (said) narration = firstLine(said, NARRATION_MAX);
    } else if (!turnStarted && raw.includes('"user"') && !raw.includes('"tool_result"')) {
      const line = parse(raw);
      if (line && isPrompt(line)) turnStarted = true;
    }
    if (customTitle && (narration || turnStarted)) break;
  }
  return { title: customTitle ?? aiTitle, narration };
}
function firstLine(text2, max) {
  for (const raw of text2.split("\n")) {
    const line = raw.replace(/^\s*(?:#+|[-*>]|\d+\.)\s+/, "").replace(/\*\*|__|`/g, "").replace(/\[([^\]]*)\]\([^)]*\)/g, "$1").replace(/\s+/g, " ").trim();
    if (line) return line.length > max ? `${line.slice(0, max - 1).trimEnd()}\u2026` : line;
  }
  return null;
}
var USAGE_MAX_BYTES = 64 * 1024 * 1024;
function readUsage(file, offset, subagent = false) {
  if (!file) return null;
  let fd;
  try {
    fd = (0, import_node_fs3.openSync)(file, "r");
  } catch {
    return null;
  }
  try {
    const size = (0, import_node_fs3.fstatSync)(fd).size;
    if (offset === void 0 || offset > size) return { usage: [], offset: size };
    if (size - offset > USAGE_MAX_BYTES) return { usage: [], offset: size };
    const buf = Buffer.alloc(size - offset);
    (0, import_node_fs3.readSync)(fd, buf, 0, buf.length, offset);
    const end = buf.lastIndexOf(10) + 1;
    return { usage: parseUsage(buf.subarray(0, end).toString("utf8"), subagent), offset: offset + end };
  } catch {
    return null;
  } finally {
    (0, import_node_fs3.closeSync)(fd);
  }
}
var count = (v) => typeof v === "number" && Number.isFinite(v) && v > 0 ? Math.round(v) : 0;
function parseUsage(text2, subagent = false) {
  const messages = /* @__PURE__ */ new Map();
  let unnamed = 0;
  for (const raw of text2.split("\n")) {
    if (!raw.includes('"usage"') || !raw.includes('"assistant"')) continue;
    const line = parse(raw);
    const m = line?.message;
    if (!line || line.type !== "assistant" || line.isSidechain && !subagent || !m?.usage || !m.model || m.model.startsWith("<")) continue;
    const u = m.usage;
    const next = {
      model: m.model,
      input: count(u.input_tokens),
      output: count(u.output_tokens),
      cacheWrite: count(u.cache_creation_input_tokens),
      cacheWrite1h: count(u.cache_creation?.ephemeral_1h_input_tokens),
      cacheRead: count(u.cache_read_input_tokens)
    };
    const id = m.id ?? `unnamed-${unnamed++}`;
    const seen = messages.get(id);
    messages.set(id, seen ? maxUsage(seen, next) : next);
  }
  const byModel = /* @__PURE__ */ new Map();
  for (const u of messages.values()) {
    const total = byModel.get(u.model);
    byModel.set(u.model, total ? addUsage(total, u) : { ...u });
  }
  return [...byModel.values()].filter((u) => u.input + u.output + u.cacheWrite + u.cacheRead > 0);
}
var FIELDS = ["input", "output", "cacheWrite", "cacheWrite1h", "cacheRead"];
function maxUsage(a, b) {
  const out = { ...a };
  for (const f of FIELDS) out[f] = Math.max(a[f], b[f]);
  return out;
}
function addUsage(a, b) {
  const out = { ...a };
  for (const f of FIELDS) out[f] = a[f] + b[f];
  return out;
}

// src/context.ts
var TICKET = /(?:^|[^A-Za-z0-9])([A-Z][A-Z0-9]{1,9}-\d+)(?![A-Za-z0-9])/;
function ticketFromBranch(branch) {
  if (!branch) return null;
  const m = TICKET.exec(branch);
  if (!m) return null;
  const rest = branch.slice(m.index + m[0].length);
  const words = rest.replace(/[-_/]+/g, " ").trim();
  return { key: m[1], words };
}
function storyFrom(branch, title) {
  const ticket = ticketFromBranch(branch);
  const story = ticket ? [ticket.key, title || ticket.words].filter(Boolean).join(": ") : title;
  return story ? story.slice(0, LIMITS.storyLength) : null;
}
var text = (v) => typeof v === "string" && v.trim() ? v.trim() : null;
function taskFromTool(toolName, input) {
  if (toolName === "TodoWrite") {
    const todos = input?.todos;
    if (!Array.isArray(todos)) return void 0;
    const now = todos.find((t) => t?.status === "in_progress");
    if (now) return oneLine(text(now.activeForm) ?? text(now.content));
    return todos.every((t) => t?.status === "completed") ? null : void 0;
  }
  if (toolName === "TaskUpdate" || toolName === "TaskCreate") {
    const t = input;
    if (t?.status === "in_progress") return oneLine(text(t.activeForm) ?? text(t.subject)) ?? void 0;
  }
  return void 0;
}
function oneLine(s) {
  return s ? firstLine(s, LIMITS.taskLength) : null;
}
function promptText(prompt) {
  if (!prompt) return null;
  const cleaned = prompt.replace(/<pasted_content\b[^>]*>[\s\S]*?<\/pasted_content>/g, "[pasted text]").replace(/\n{3,}/g, "\n\n").trim();
  if (!cleaned) return null;
  return cleaned.length > LIMITS.promptLength ? `${cleaned.slice(0, LIMITS.promptLength - 1)}\u2026` : cleaned;
}

// src/describe.ts
var VERBS = {
  Bash: "Running a command",
  PowerShell: "Running a command",
  Read: "Reading files",
  Edit: "Editing files",
  MultiEdit: "Editing files",
  Write: "Writing files",
  NotebookEdit: "Editing a notebook",
  Grep: "Searching the code",
  Glob: "Finding files",
  LS: "Listing files",
  WebFetch: "Reading a web page",
  WebSearch: "Searching the web",
  TodoWrite: "Updating its task list",
  Task: "Running a sub-agent",
  Agent: "Running a sub-agent",
  Skill: "Using a skill",
  ToolSearch: "Loading tools",
  EnterPlanMode: "Planning",
  AskUserQuestion: "Asking you a question",
  ExitPlanMode: "Waiting for you to approve its plan"
};
var WAITING_TOOLS = /* @__PURE__ */ new Set(["AskUserQuestion", "ExitPlanMode"]);
function describeTool(toolName, toolInput) {
  const waiting = WAITING_TOOLS.has(toolName);
  const raw = toolInput?.description;
  const description = typeof raw === "string" ? raw.trim().replace(/\s+/g, " ").slice(0, 200) : "";
  if (description && !waiting) {
    return { activity: toolName === "Agent" || toolName === "Task" ? `Sub-agent: ${description}` : description, waiting };
  }
  const verb = VERBS[toolName];
  if (verb) return { activity: verb, waiting };
  const mcp = /^mcp__(.+?)__(.+)$/.exec(toolName);
  if (mcp) return { activity: `Using ${mcp[1]}: ${mcp[2]}`, waiting };
  return { activity: `Using ${toolName}`, waiting };
}

// src/result.ts
var CHECKS_HEADING = /^\s*(?:#{1,6}\s*|\*\*)?(?:how to (?:check|verify|test|try)|what you should see|to (?:check|verify)|acceptance(?: steps| checks)?|verify|try it(?: out)?|checks?)\b.*$/i;
function splitChecks(message) {
  const lines = message.split("\n");
  const at = lines.findIndex((l) => CHECKS_HEADING.test(l) && l.trim().length < 80);
  if (at < 0) return { summary: message.trim(), checks: [] };
  const checks = [];
  let end = at + 1;
  for (; end < lines.length; end++) {
    const line = lines[end];
    const item = /^\s*(?:[-*+]|\d+[.)])\s+(?:\[[ xX]\]\s+)?(.+)$/.exec(line);
    if (item) checks.push(item[1].trim());
    else if (line.trim() && checks.length) break;
  }
  if (!checks.length) return { summary: message.trim(), checks: [] };
  const summary = [...lines.slice(0, at), ...lines.slice(end)].join("\n").trim();
  return { summary, checks };
}
function resultFrom(commit, finalMessage) {
  const { summary, checks } = splitChecks(finalMessage ?? "");
  return {
    title: commit.subject.slice(0, LIMITS.resultTitleLength) || commit.sha.slice(0, 7),
    summary: (summary || commit.subject).slice(0, LIMITS.resultSummaryLength),
    checks: checks.slice(0, LIMITS.resultChecks).map((c) => c.slice(0, LIMITS.resultCheckLength)),
    commit: commit.sha,
    commitUrl: commit.url,
    branch: commit.branch,
    pushed: commit.pushed
  };
}

// src/hook.ts
var PLAIN_EVENTS = /* @__PURE__ */ new Set(["Notification", "SessionEnd", "StopFailure", "SubagentStart", "SubagentStop"]);
var WAITING_NOTIFICATIONS = /* @__PURE__ */ new Set(["permission_prompt", "elicitation_dialog", "elicitation_url_dialog", "agent_needs_input"]);
var IDLE_NOTIFICATIONS = /* @__PURE__ */ new Set(["idle_prompt"]);
var USAGE_EVENTS = /* @__PURE__ */ new Set(["Stop", "UserPromptSubmit", "SessionEnd"]);
var END_REASONS = {
  clear: "Session cleared",
  resume: "Switched to another session",
  logout: "Logged out",
  prompt_input_exit: "Session closed"
};
function surface(entrypoint) {
  if (!entrypoint) return null;
  if (entrypoint.includes("vscode")) return "vscode";
  if (entrypoint === "cli") return "terminal";
  if (entrypoint.startsWith("sdk")) return "sdk";
  return entrypoint;
}
function subagentAgentId(session, subagentId) {
  return `${session.agentId}/${subagentId}`;
}
function planHook(input, existing, runningSubagents, ctx) {
  const now = ctx.now.toISOString();
  const event = input.hook_event_name;
  const sid = input.session_id;
  const isNew = !existing || event === "SessionStart";
  const cwd = input.cwd ?? existing?.cwd ?? ".";
  const project = existing && !isNew ? existing.project : ctx.project(cwd);
  const title = input.session_title?.trim();
  let session;
  let sessionChanged = false;
  if (isNew) {
    session = {
      sessionId: sid,
      agentId: `${ctx.machine}/claude/${sid}`,
      name: title || existing?.name || `${project}-${sid.slice(0, 4)}`,
      project,
      cwd,
      pid: ctx.claudePid ?? existing?.pid ?? null,
      startedAt: existing?.startedAt ?? now,
      endedAt: null,
      details: {
        sessionId: sid,
        model: input.model ?? existing?.details.model ?? null,
        surface: surface(ctx.entrypoint),
        branch: ctx.branch(cwd),
        folder: cwd,
        permissionMode: input.permission_mode ?? null
      }
    };
    sessionChanged = true;
  } else {
    session = { ...existing };
    if (title && title !== session.name) {
      session.name = title;
      sessionChanged = true;
    }
    if (session.endedAt && event !== "SessionEnd") {
      session.endedAt = null;
      sessionChanged = true;
    }
  }
  const main2 = !input.agent_id;
  let context = ctx.context;
  const what = {};
  if (main2 && input.transcript_path) {
    const sameFile = context.usagePath === input.transcript_path;
    const restart = event === "SessionStart" && input.source !== "compact";
    if (restart || !sameFile || USAGE_EVENTS.has(event)) {
      const read = ctx.usage(input.transcript_path, restart || !sameFile ? void 0 : context.usageOffset);
      if (read) {
        if (read.offset !== context.usageOffset || !sameFile) context = { ...context, usagePath: input.transcript_path, usageOffset: read.offset };
        if (read.usage.length) what.usage = read.usage;
      }
    }
  }
  if (main2 && !PLAIN_EVENTS.has(event)) {
    let transcript = null;
    const read = () => transcript ??= ctx.transcript(input.transcript_path);
    if (event === "UserPromptSubmit") {
      context = { ...context, task: void 0, headAtPrompt: ctx.head(cwd) ?? void 0, reported: void 0 };
      if (ctx.sendPrompts) what.prompt = promptText(input.prompt);
      what.task = context.todo ?? null;
      what.turn = "start";
    }
    if (event === "Stop") {
      what.turn = "end";
      const head = context.headAtPrompt !== void 0 && !context.reported ? ctx.head(cwd) : null;
      if (head && head !== context.headAtPrompt) {
        const commit = ctx.commit(cwd, head);
        if (commit) what.result = resultFrom(commit, input.last_assistant_message);
        context = { ...context, headAtPrompt: head, reported: true };
      }
    }
    if (event === "PreToolUse") {
      const todo = taskFromTool(input.tool_name ?? "", input.tool_input);
      if (todo !== void 0 && todo !== (context.todo ?? null)) context = { ...context, todo: todo ?? void 0 };
      const task = context.task ?? context.todo ?? read().narration;
      if (task) what.task = task;
    }
    const title2 = input.session_title?.trim() || read().title;
    const story = context.story ?? storyFrom(ctx.branch(cwd), title2);
    if (story) what.story = story;
    if (context.workType) what.workType = context.workType;
  }
  const base = () => ({
    agentId: session.agentId,
    kind: "claude-code",
    machine: ctx.machine,
    name: session.name,
    project: session.project,
    instructionsVersion: INSTRUCTIONS_VERSION,
    at: now,
    // A session seen for the first time sends everything the manager needs to show it.
    ...isNew ? { parentId: null, details: session.details } : {}
  });
  const sessionReport = (state, activity, coalesce = false) => ({
    report: { ...base(), state, activity, ...what },
    coalesce
  });
  const subReport = (subagentId, agentType, state, activity, coalesce = false) => ({
    report: {
      agentId: subagentAgentId(session, subagentId),
      kind: "claude-code",
      machine: ctx.machine,
      name: agentType || "sub-agent",
      project: session.project,
      parentId: session.agentId,
      instructionsVersion: INSTRUCTIONS_VERSION,
      state,
      activity,
      at: now
    },
    coalesce
  });
  const plan = { session, sessionChanged, reports: [], ensureDaemon: isNew };
  if (context !== ctx.context) plan.context = context;
  switch (event) {
    case "SessionStart": {
      if (input.source === "compact") {
        plan.reports.push({ report: { ...base(), activity: "Compacted its conversation", ...what }, coalesce: false });
        break;
      }
      const source = input.source && input.source !== "startup" ? ` (${input.source})` : "";
      plan.reports.push(sessionReport("idle", `Session started${source}`));
      break;
    }
    case "UserPromptSubmit":
      plan.reports.push(sessionReport("working", "Working on your prompt"));
      plan.ensureDaemon = true;
      break;
    case "PreToolUse": {
      const { activity, waiting } = describeTool(input.tool_name ?? "a tool", input.tool_input);
      const state = waiting ? "waiting" : "working";
      plan.reports.push(
        input.agent_id ? subReport(input.agent_id, input.agent_type, state, activity, !waiting) : sessionReport(state, activity, !waiting)
      );
      break;
    }
    case "Notification": {
      const type = input.notification_type ?? "";
      if (WAITING_NOTIFICATIONS.has(type)) {
        plan.reports.push(sessionReport("waiting", input.message?.trim() || input.title?.trim() || "Waiting for you"));
      } else if (IDLE_NOTIFICATIONS.has(type)) {
        plan.reports.push(sessionReport("idle", "Waiting for your next prompt"));
      }
      break;
    }
    case "Stop":
      plan.reports.push(sessionReport("idle", "Finished its turn"));
      break;
    case "StopFailure":
      plan.reports.push(sessionReport("failed", `Stopped by an API error (${input.error ?? "unknown"})`));
      break;
    case "SubagentStart":
      if (input.agent_id) {
        plan.subagentStart = { agentId: subagentAgentId(session, input.agent_id), subagentId: input.agent_id, agentType: input.agent_type ?? "sub-agent", startedAt: now };
        plan.reports.push(subReport(input.agent_id, input.agent_type, "working", "Started"));
      }
      break;
    case "SubagentStop":
      if (input.agent_id) {
        plan.subagentStop = input.agent_id;
        const stopped = subReport(input.agent_id, input.agent_type, "stopped", "Finished");
        const usage = ctx.usage(input.agent_transcript_path, 0, true)?.usage;
        if (usage?.length) stopped.report.usage = usage;
        plan.reports.push(stopped);
      }
      break;
    case "SessionEnd":
      session.endedAt = now;
      plan.sessionChanged = true;
      plan.ensureDaemon = false;
      plan.reports.push(sessionReport("stopped", END_REASONS[input.reason ?? ""] ?? "Session ended"));
      for (const sub of runningSubagents) plan.reports.push(subReport(sub.subagentId, sub.agentType, "stopped", "Session ended"));
      break;
    default:
      if (isNew) plan.reports.push(sessionReport("working", "Working"));
  }
  return plan;
}

// src/inbox.ts
var import_node_net = require("node:net");

// src/proc.ts
var import_node_child_process2 = require("node:child_process");
function isAlive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch (e) {
    return e.code === "EPERM";
  }
}
function processTable() {
  const table = /* @__PURE__ */ new Map();
  if (process.platform === "win32") {
    const out = (0, import_node_child_process2.execFileSync)(
      "powershell.exe",
      [
        "-NoProfile",
        "-NonInteractive",
        "-Command",
        'Get-CimInstance Win32_Process -Property ProcessId,ParentProcessId,Name | ForEach-Object { "$($_.ProcessId)`t$($_.ParentProcessId)`t$($_.Name)" }'
      ],
      { encoding: "utf8", windowsHide: true, timeout: 15e3 }
    );
    for (const line of out.split(/\r?\n/)) {
      const [pid, ppid, name] = line.split("	");
      if (pid && ppid) table.set(Number(pid), { pid: Number(pid), ppid: Number(ppid), name: name ?? "" });
    }
  } else {
    const out = (0, import_node_child_process2.execFileSync)("ps", ["-A", "-o", "pid=,ppid=,comm="], { encoding: "utf8", timeout: 15e3 });
    for (const line of out.split("\n")) {
      const m = /^\s*(\d+)\s+(\d+)\s+(.*)$/.exec(line);
      if (m) table.set(Number(m[1]), { pid: Number(m[1]), ppid: Number(m[2]), name: m[3].trim() });
    }
  }
  return table;
}
function ancestors() {
  const table = processTable();
  const chain = [];
  let pid = process.ppid;
  while (pid > 0 && !chain.includes(pid)) {
    chain.push(pid);
    pid = table.get(pid)?.ppid ?? 0;
  }
  return chain;
}

// src/send.ts
var SendError = class extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
};
function post(config, path, body, timeoutMs = 5e3) {
  return call(config, "POST", path, body, timeoutMs);
}
function get(config, path, timeoutMs = 15e3) {
  return call(config, "GET", path, void 0, timeoutMs);
}
function postFile(config, path, bytes, contentType, timeoutMs = 12e4) {
  return call(config, "POST", path, { bytes, contentType }, timeoutMs);
}
function isFile(body) {
  return typeof body === "object" && body !== null && Buffer.isBuffer(body.bytes);
}
async function call(config, method, path, body, timeoutMs) {
  let res;
  const file = isFile(body) ? body : null;
  try {
    res = await fetch(`${config.url}/api/v1${path}`, {
      method,
      // Not Authorization: Static Web Apps replaces that header before the API sees it.
      headers: { "content-type": file ? file.contentType : "application/json", "x-agent-manager-key": config.key },
      body: file ? new Uint8Array(file.bytes) : body === void 0 ? void 0 : JSON.stringify(body),
      signal: AbortSignal.timeout(timeoutMs)
    });
  } catch (e) {
    const cause = e.name === "TimeoutError" ? `no answer within ${timeoutMs} ms` : e.message;
    throw new SendError(`Could not reach ${config.url}: ${cause}`);
  }
  const text2 = await res.text();
  let parsed;
  try {
    parsed = JSON.parse(text2);
  } catch {
    throw new SendError(`${config.url} answered ${res.status} with something that isn't JSON; is the URL right?`, res.status);
  }
  if (!res.ok) throw new SendError(parsed.error ?? `HTTP ${res.status}`, res.status);
  return parsed;
}

// src/sessions.ts
var import_node_fs4 = require("node:fs");
var import_node_path4 = require("node:path");
var safe = (s) => s.replace(/[^A-Za-z0-9._-]/g, "_");
var dirOf = (sessionId) => (0, import_node_path4.join)(paths.sessions(), safe(sessionId));
var sessionFile = (sessionId) => (0, import_node_path4.join)(dirOf(sessionId), "session.json");
var subFile = (sessionId, subId) => (0, import_node_path4.join)(dirOf(sessionId), `sub-${safe(subId)}.json`);
var contextFile = (sessionId) => (0, import_node_path4.join)(dirOf(sessionId), "context.json");
var inboxFile = (sessionId) => (0, import_node_path4.join)(dirOf(sessionId), "inbox.json");
var sendFile = (sessionId, agentId) => (0, import_node_path4.join)(dirOf(sessionId), `send-${safe(agentId.split("/").pop() ?? "main")}.json`);
function readSession(sessionId) {
  return readJsonFile(sessionFile(sessionId));
}
function writeSession(s) {
  writeJsonFile(sessionFile(s.sessionId), s);
}
function listSessions() {
  if (!(0, import_node_fs4.existsSync)(paths.sessions())) return [];
  return (0, import_node_fs4.readdirSync)(paths.sessions()).map((d) => readJsonFile((0, import_node_path4.join)(paths.sessions(), d, "session.json"))).filter((s) => s !== null);
}
function addSubagent(sessionId, sub) {
  writeJsonFile(subFile(sessionId, sub.subagentId), sub);
}
function removeSubagent(sessionId, subId) {
  try {
    (0, import_node_fs4.unlinkSync)(subFile(sessionId, subId));
  } catch {
  }
}
function listSubagents(sessionId) {
  const dir = dirOf(sessionId);
  if (!(0, import_node_fs4.existsSync)(dir)) return [];
  return (0, import_node_fs4.readdirSync)(dir).filter((f) => f.startsWith("sub-")).map((f) => readJsonFile((0, import_node_path4.join)(dir, f))).filter((s) => s !== null);
}
function readContext(sessionId) {
  return readJsonFile(contextFile(sessionId)) ?? {};
}
function writeContext(sessionId, context) {
  writeJsonFile(contextFile(sessionId), context);
}
function readInbox(sessionId) {
  return readJsonFile(inboxFile(sessionId));
}
function writeInbox(sessionId, inbox) {
  writeJsonFile(inboxFile(sessionId), inbox);
}
function removeInbox(sessionId) {
  if (!(0, import_node_fs4.existsSync)(inboxFile(sessionId))) return;
  try {
    (0, import_node_fs4.unlinkSync)(inboxFile(sessionId));
  } catch {
  }
}
function readSendState(sessionId, agentId) {
  return readJsonFile(sendFile(sessionId, agentId)) ?? { lastSentAt: 0, pendingSeq: "" };
}
function writeSendState(sessionId, agentId, state) {
  writeJsonFile(sendFile(sessionId, agentId), state);
}
function pruneSessions(days) {
  if (!(0, import_node_fs4.existsSync)(paths.sessions())) return;
  const cutoff = Date.now() - days * 864e5;
  for (const d of (0, import_node_fs4.readdirSync)(paths.sessions())) {
    const dir = (0, import_node_path4.join)(paths.sessions(), d);
    const s = readJsonFile((0, import_node_path4.join)(dir, "session.json"));
    const ended = s?.endedAt ? Date.parse(s.endedAt) : null;
    const orphan = !s && (0, import_node_fs4.statSync)(dir).mtimeMs < cutoff;
    if (ended !== null && ended < cutoff || orphan) (0, import_node_fs4.rmSync)(dir, { recursive: true, force: true });
  }
}

// src/inbox.ts
var POST_TIMEOUT_MS = 5e3;
var BYPASS = "bypassPermissions";
function nextInbox(enabled, event, permissionMode, env, current) {
  if (!enabled || event === "SessionEnd") return current ? null : void 0;
  const socket = env.CLAUDE_CODE_MESSAGING_SOCKET;
  const token = env.CLAUDE_CODE_MESSAGING_TOKEN;
  if (!socket || !token) return void 0;
  const next = { socket, token, permissionMode: permissionMode ?? current?.permissionMode ?? null };
  const same = current && current.socket === next.socket && current.token === next.token && current.permissionMode === next.permissionMode;
  return same ? void 0 : next;
}
function syncInbox(config, sessionId, event, permissionMode) {
  const next = nextInbox(config.messages === true, event, permissionMode, process.env, readInbox(sessionId));
  if (next === null) removeInbox(sessionId);
  else if (next) writeInbox(sessionId, next);
}
function formatMessage(m) {
  return `${m.text}

(Sent from Agent Manager Delux by ${m.from})`;
}
function postToSession(inbox, text2, timeoutMs = POST_TIMEOUT_MS) {
  return new Promise((resolve3, reject) => {
    const socket = (0, import_node_net.connect)(inbox.socket);
    const timer = setTimeout(() => {
      socket.destroy();
      reject(new Error(`The session's inbox didn't take the message within ${timeoutMs} ms`));
    }, timeoutMs);
    socket.on("connect", () => {
      const auth = JSON.stringify({ type: "auth", token: inbox.token });
      const message = JSON.stringify({ type: "user", message: { role: "user", content: text2 } });
      socket.end(`${auth}
${message}
`);
    });
    socket.on("error", (e) => {
      clearTimeout(timer);
      reject(new Error(`Couldn't reach the session's inbox: ${e.message}`));
    });
    socket.on("close", (hadError) => {
      clearTimeout(timer);
      if (!hadError) resolve3();
    });
    socket.resume();
  });
}
async function deliverMessage(m, inbox, machine, send = postToSession) {
  const failed = (reason) => ({ id: m.id, machine, status: "failed", reason });
  if (!inbox) return failed("The session isn\u2019t open on this PC, or hasn\u2019t run a hook since messages were turned on");
  if (inbox.permissionMode === BYPASS) return failed("The session skips permission prompts, so agentctl won\u2019t post into it");
  try {
    await send(inbox, formatMessage(m));
  } catch (e) {
    return failed(e.message);
  }
  return { id: m.id, machine, status: "delivered" };
}
var unacked = /* @__PURE__ */ new Map();
async function checkInbox(config) {
  const inboxes = /* @__PURE__ */ new Map();
  for (const s of listSessions()) {
    if (s.endedAt || s.pid !== null && !isAlive(s.pid)) continue;
    const inbox = readInbox(s.sessionId);
    if (inbox) inboxes.set(s.agentId, inbox);
  }
  if (inboxes.size === 0) return;
  const { messages } = await post(config, "/inbox", { machine: config.machine });
  for (const id of unacked.keys()) if (!messages.some((m) => m.id === id)) unacked.delete(id);
  for (const m of messages) {
    let ack = unacked.get(m.id);
    if (!ack) {
      ack = await deliverMessage(m, inboxes.get(m.agentId), config.machine);
      logLine(`inbox: message ${m.id} for ${m.agentId}: ${ack.status}${ack.reason ? ` (${ack.reason})` : ""}`);
      unacked.set(m.id, ack);
    }
    try {
      await post(config, "/inbox/ack", ack);
      unacked.delete(m.id);
    } catch (e) {
      logLine(`inbox: could not acknowledge ${m.id}: ${e.message}`);
    }
  }
}
function removeAllInboxes() {
  for (const s of listSessions()) removeInbox(s.sessionId);
}

// src/daemon.ts
var BEAT_MS = 6e4;
var INBOX_MS = 5e3;
var EXIT_AFTER_IDLE_MS = 10 * 6e4;
var STALE_BEAT_MS = 3 * 6e4;
function ensureDaemon(scriptPath2) {
  const d = readJsonFile(paths.daemon());
  if (d && isAlive(d.pid) && Date.now() - Date.parse(d.beatAt) < STALE_BEAT_MS) return;
  (0, import_node_child_process3.spawn)(process.execPath, [scriptPath2, "daemon"], { detached: true, stdio: "ignore", windowsHide: true }).unref();
}
function takeLock() {
  const lock = `${paths.daemon()}.lock`;
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const fd = (0, import_node_fs5.openSync)(lock, "wx");
      (0, import_node_fs5.writeSync)(fd, String(process.pid));
      (0, import_node_fs5.closeSync)(fd);
      return true;
    } catch {
      const holder = readJsonFile(lock);
      if (typeof holder === "number" && holder !== process.pid && isAlive(holder)) return false;
      try {
        (0, import_node_fs5.unlinkSync)(lock);
      } catch {
        return false;
      }
    }
  }
  return false;
}
function releaseLock() {
  try {
    (0, import_node_fs5.unlinkSync)(`${paths.daemon()}.lock`);
  } catch {
  }
}
function fullReport(config, s, state, activity) {
  return {
    agentId: s.agentId,
    kind: "claude-code",
    machine: config.machine,
    name: s.name,
    project: s.project,
    parentId: null,
    details: s.details,
    instructionsVersion: INSTRUCTIONS_VERSION,
    state,
    activity
  };
}
async function beat(config) {
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const live = [];
  for (const s of listSessions()) {
    if (s.endedAt) continue;
    if (s.pid !== null && !isAlive(s.pid)) {
      writeSession({ ...s, endedAt: now });
      for (const sub of listSubagents(s.sessionId)) removeSubagent(s.sessionId, sub.subagentId);
      await post(config, "/report", fullReport(config, s, "stopped", "Window closed")).catch(
        (e) => logLine(`heartbeat: could not report ${s.agentId} closed: ${e.message}`)
      );
      continue;
    }
    live.push(s);
  }
  const agentIds = live.flatMap((s) => [s.agentId, ...listSubagents(s.sessionId).map((sub) => subagentAgentId(s, sub.subagentId))]);
  const res = await post(config, "/heartbeat", { machine: config.machine, kind: "claude-code", agentIds });
  for (const id of res.stored.unknown) {
    const s = live.find((x) => x.agentId === id);
    if (s) await post(config, "/report", fullReport(config, s, "idle", "Reconnected")).catch((e) => logLine(`heartbeat: ${e.message}`));
  }
  return live.length;
}
async function runDaemon() {
  if (!takeLock()) return;
  process.on("exit", releaseLock);
  logLine("heartbeat started");
  let idleSince = null;
  let lastPrune = 0;
  for (; ; ) {
    writeJsonFile(paths.daemon(), { pid: process.pid, beatAt: (/* @__PURE__ */ new Date()).toISOString() });
    try {
      const live = await beat(loadConfig());
      idleSince = live > 0 ? null : idleSince ?? Date.now();
    } catch (e) {
      logLine(`heartbeat: ${e.message}`);
    }
    if (Date.now() - lastPrune > 36e5) {
      pruneSessions(2);
      lastPrune = Date.now();
    }
    if (idleSince !== null && Date.now() - idleSince > EXIT_AFTER_IDLE_MS) {
      logLine("heartbeat stopping: no live sessions for 10 minutes");
      return;
    }
    await untilNextBeat();
  }
}
var sleep = (ms) => new Promise((r) => setTimeout(r, Math.max(0, ms)));
async function untilNextBeat() {
  const next = Date.now() + BEAT_MS;
  while (Date.now() < next) {
    let config = null;
    try {
      config = loadConfig();
    } catch {
    }
    if (!config?.messages) return sleep(next - Date.now());
    await sleep(Math.min(INBOX_MS, next - Date.now()));
    await checkInbox(config).catch((e) => logLine(`inbox: ${e.message}`));
  }
}

// src/git.ts
var import_node_child_process4 = require("node:child_process");
var import_node_fs6 = require("node:fs");
var import_node_path5 = require("node:path");
function findRepoRoot(cwd) {
  let dir = (0, import_node_path5.resolve)(cwd);
  for (; ; ) {
    if ((0, import_node_fs6.existsSync)((0, import_node_path5.join)(dir, ".git"))) return dir;
    const parent = (0, import_node_path5.dirname)(dir);
    if (parent === dir) return null;
    dir = parent;
  }
}
function gitDirOf(repoRoot) {
  let gitDir = (0, import_node_path5.join)(repoRoot, ".git");
  if ((0, import_node_fs6.statSync)(gitDir).isFile()) {
    const pointer = /^gitdir:\s*(.+)$/m.exec((0, import_node_fs6.readFileSync)(gitDir, "utf8"))?.[1]?.trim();
    if (!pointer) return null;
    gitDir = (0, import_node_path5.isAbsolute)(pointer) ? pointer : (0, import_node_path5.resolve)(repoRoot, pointer);
  }
  return gitDir;
}
function readBranch(repoRoot) {
  try {
    const gitDir = gitDirOf(repoRoot);
    if (!gitDir) return null;
    const head = (0, import_node_fs6.readFileSync)((0, import_node_path5.join)(gitDir, "HEAD"), "utf8").trim();
    const ref = /^ref:\s*refs\/heads\/(.+)$/.exec(head)?.[1];
    return ref ?? (/^[0-9a-f]{7,}$/.test(head) ? head.slice(0, 7) : null);
  } catch {
    return null;
  }
}
function projectName(cwd) {
  return (0, import_node_path5.basename)(findRepoRoot(cwd) ?? (0, import_node_path5.resolve)(cwd)) || cwd;
}
function readHead(repoRoot) {
  try {
    const gitDir = gitDirOf(repoRoot);
    if (!gitDir) return null;
    const head = (0, import_node_fs6.readFileSync)((0, import_node_path5.join)(gitDir, "HEAD"), "utf8").trim();
    const ref = /^ref:\s*(.+)$/.exec(head)?.[1];
    if (!ref) return /^[0-9a-f]{40,64}$/.test(head) ? head : null;
    const common = (0, import_node_fs6.existsSync)((0, import_node_path5.join)(gitDir, "commondir")) ? (0, import_node_path5.resolve)(gitDir, (0, import_node_fs6.readFileSync)((0, import_node_path5.join)(gitDir, "commondir"), "utf8").trim()) : gitDir;
    for (const dir of [gitDir, common]) {
      const file = (0, import_node_path5.join)(dir, ref);
      if ((0, import_node_fs6.existsSync)(file)) return (0, import_node_fs6.readFileSync)(file, "utf8").trim() || null;
    }
    const packed = (0, import_node_path5.join)(common, "packed-refs");
    if (!(0, import_node_fs6.existsSync)(packed)) return null;
    const line = (0, import_node_fs6.readFileSync)(packed, "utf8").split("\n").find((l) => l.endsWith(` ${ref}`));
    return line?.split(" ")[0] ?? null;
  } catch {
    return null;
  }
}
function git(repoRoot, args) {
  return (0, import_node_child_process4.execFileSync)("git", ["-C", repoRoot, ...args], { encoding: "utf8", timeout: 4e3, windowsHide: true, stdio: ["ignore", "pipe", "ignore"] }).trim();
}
function commitWebUrl(remote, sha) {
  const m = /^(?:https?:\/\/(?:[^@/]+@)?|ssh:\/\/git@|git@)([^/:]+)[/:](.+?)(?:\.git)?\/?$/.exec(remote.trim());
  if (!m) return null;
  const [, host, path] = m;
  if (host === "github.com") return `https://github.com/${path}/commit/${sha}`;
  if (host.includes("gitlab")) return `https://${host}/${path}/-/commit/${sha}`;
  if (host === "bitbucket.org") return `https://bitbucket.org/${path}/commits/${sha}`;
  if (host === "dev.azure.com" || host.endsWith("visualstudio.com")) {
    const ado = /^(?:v3\/)?([^/]+)\/([^/]+)\/(?:_git\/)?([^/]+)$/.exec(path);
    return ado ? `https://dev.azure.com/${ado[1]}/${ado[2]}/_git/${ado[3]}/commit/${sha}` : null;
  }
  return null;
}
function commitInfo(repoRoot, sha) {
  try {
    const subject = git(repoRoot, ["log", "-1", "--format=%s", sha]);
    let url = null;
    try {
      url = commitWebUrl(git(repoRoot, ["remote", "get-url", "origin"]), sha);
    } catch {
    }
    let pushed = false;
    try {
      pushed = git(repoRoot, ["branch", "-r", "--contains", sha]) !== "";
    } catch {
    }
    return { sha, subject, branch: readBranch(repoRoot), url, pushed };
  } catch {
    return null;
  }
}
function hasUncommittedChanges(repoRoot) {
  try {
    return git(repoRoot, ["status", "--porcelain"]) !== "";
  } catch {
    return null;
  }
}

// src/settings.ts
var ASYNC_EVENTS = [
  "SessionStart",
  "UserPromptSubmit",
  "PreToolUse",
  "Notification",
  "Stop",
  "StopFailure",
  "SubagentStart",
  "SubagentStop"
];
var SYNC_EVENTS = ["SessionEnd"];
function isOurs(hook) {
  const parts = [hook.command, ...Array.isArray(hook.args) ? hook.args : []].filter((p) => typeof p === "string");
  return parts.some((p) => /agentctl\.js["']?(\s+hook)?$/i.test(p.trim())) && parts.some((p) => /(^|\s)hook$/.test(p.trim()));
}
function withoutAgentctlHooks(settings) {
  const hooks = settings.hooks;
  if (!hooks || typeof hooks !== "object") return settings;
  const next = {};
  for (const [event, groups] of Object.entries(hooks)) {
    if (!Array.isArray(groups)) {
      next[event] = groups;
      continue;
    }
    const kept = groups.map((g) => ({ ...g, hooks: Array.isArray(g.hooks) ? g.hooks.filter((h) => !isOurs(h)) : g.hooks })).filter((g) => !Array.isArray(g.hooks) || g.hooks.length > 0);
    if (kept.length) next[event] = kept;
  }
  const out = { ...settings, hooks: next };
  if (Object.keys(next).length === 0) delete out.hooks;
  return out;
}
function withAgentctlHooks(settings, nodePath, scriptPath2) {
  const clean = withoutAgentctlHooks(settings);
  const hooks = { ...clean.hooks ?? {} };
  const handler = (async) => ({
    type: "command",
    command: nodePath,
    args: [scriptPath2, "hook"],
    ...async ? { async: true, timeout: 30 } : { timeout: 5 }
  });
  for (const event of ASYNC_EVENTS) hooks[event] = [...hooks[event] ?? [], { hooks: [handler(true)] }];
  for (const event of SYNC_EVENTS) hooks[event] = [...hooks[event] ?? [], { hooks: [handler(false)] }];
  return { ...clean, hooks };
}
function hasAgentctlHooks(settings) {
  const hooks = settings.hooks;
  if (!hooks) return false;
  return [...ASYNC_EVENTS, ...SYNC_EVENTS].every(
    (event) => (hooks[event] ?? []).some((g) => Array.isArray(g.hooks) && g.hooks.some(isOurs))
  );
}

// src/agentctl.ts
var HELP = `agentctl: reports the Claude Code sessions on this PC to Agent Manager Delux.

  agentctl install --url <url> [--key <key>] [--machine <name>]
      Saves the URL and machine key, checks them, and adds the reporting hooks to
      ~/.claude/settings.json (backing it up first). The key defaults to AGENT_MANAGER_KEY.
      Run again after downloading a new agentctl.js to update: the URL and key are kept.
      --allow-messages lets you send messages to this PC's sessions from their page in Agent
      Manager; --no-messages turns that off again. Off by default; the choice is kept on update.
  agentctl uninstall          Removes the hooks (the config stays).
  agentctl status "<text>" [--state working|waiting|idle]
      Sets this session's one-line activity. Run it from a Claude Code shell.
  agentctl story "<text>" [--type <kind of work>]
      Sets the story this session is on: the ticket and its title, or a one-line summary of the
      goal. "agentctl story --clear" goes back to the one worked out from the branch and the
      session's title. --type says what kind of work it is, for the Reporting tab: one of
      ${WORK_TYPES.join(", ")}.
  agentctl task "<text>"      Sets the technical step it is on, until the next prompt (or --clear).
  agentctl done "<summary>" [--check "<what you should see>"]... [--title "<name>"] [--uncommitted]
      Reports finished work: the commit (its subject is the title, linked to GitHub), the prompt,
      the summary (Markdown; "-" reads it from stdin) and acceptance checks. Commit first: it
      refuses while there are uncommitted changes, unless --uncommitted.
  agentctl blocker "<what's in the way>" [--details "<more>"] [--screenshot <file>]... [--video <file>]
                  [--screen] [--wait <seconds>]
      Reports something you can't get past without the person (a login, a key, a decision, a
      broken machine). It shows on the Blockers tab, where they answer it. --details is Markdown
      ("-" reads it from stdin): what you tried and exactly what you need. --screenshot and --video
      attach files (PNG, JPEG, WebP, GIF up to 8 MB; MP4, WebM up to 25 MB); --screen captures the
      whole screen (macOS and Linux). --wait waits up to that many seconds for the answer and prints it.
  agentctl blocker <id> [--wait <seconds>]
      Prints whether the blocker is answered, and the answer; --wait waits for it first.
  agentctl perf [--game <name>] [--days <n>] [--limit <n>] [--json]
      Lists the performance sessions games have sent, newest first, one line a session.
  agentctl perf <sessionId>   Prints one session as JSON: its totals, worst hitches and samples.
  agentctl test               Sends a test report and prints the answer.
  agentctl doctor             Shows the config, hooks, heartbeat, sessions and recent errors.
  agentctl hook               (used by the hooks) Reads one hook event from stdin.
  agentctl daemon             (started by the hooks) Runs the heartbeat.

Exit codes: 0 done, 1 bad usage, 2 not set up, 3 session not found, 4 Agent Manager Delux refused or
unreachable, 5 uncommitted changes (done), 6 the blocker is still open after --wait.`;
var UsageError = class extends Error {
};
var NotFoundError = class extends Error {
};
var SWITCHES = /* @__PURE__ */ new Set(["clear", "uncommitted", "allow-messages", "no-messages", "json", "screen"]);
var REPEATED = /* @__PURE__ */ new Set(["check", "screenshot", "video"]);
function parseArgs(argv) {
  const positional = [];
  const flags = {};
  const lists = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith("--")) {
      const [name, inline] = a.slice(2).split("=", 2);
      if (SWITCHES.has(name) && inline === void 0) {
        flags[name] = "true";
        continue;
      }
      const value = inline ?? argv[i + 1];
      if (value === void 0 || inline === void 0 && value.startsWith("--")) throw new UsageError(`--${name} needs a value`);
      flags[name] = value;
      if (REPEATED.has(name)) (lists[name] ??= []).push(value);
      if (inline === void 0) i++;
    } else {
      positional.push(a);
    }
  }
  return { positional, flags, lists };
}
function scriptPath() {
  return (0, import_node_path6.resolve)(process.argv[1] ?? paths.script());
}
async function readStdin() {
  const chunks = [];
  for await (const chunk of process.stdin) chunks.push(chunk);
  return Buffer.concat(chunks).toString("utf8");
}
var COALESCE_MS = 2e3;
async function deliver(config, sessionId, planned, timeoutMs) {
  const { report } = planned;
  const state = readSendState(sessionId, report.agentId);
  const wait = state.lastSentAt + COALESCE_MS - Date.now();
  if (planned.coalesce && wait > 0) {
    const seq = `${process.pid}-${Date.now()}`;
    writeSendState(sessionId, report.agentId, { ...state, pendingSeq: seq });
    await new Promise((r) => setTimeout(r, wait));
    if (readSendState(sessionId, report.agentId).pendingSeq !== seq) return;
  }
  writeSendState(sessionId, report.agentId, { lastSentAt: Date.now(), pendingSeq: "" });
  await post(config, "/report", report, timeoutMs);
}
async function hookCommand() {
  const raw = await readStdin();
  let input;
  try {
    input = JSON.parse(raw);
  } catch {
    logLine(`hook: stdin was not JSON: ${raw.slice(0, 200)}`);
    return;
  }
  if (!input.session_id || !input.hook_event_name) {
    logLine("hook: stdin had no session_id or hook_event_name");
    return;
  }
  const config = loadConfig();
  const existing = readSession(input.session_id);
  const plan = planHook(input, existing, input.hook_event_name === "SessionEnd" ? listSubagents(input.session_id) : [], {
    machine: config.machine,
    now: /* @__PURE__ */ new Date(),
    claudePid: process.ppid || null,
    entrypoint: process.env.CLAUDE_CODE_ENTRYPOINT,
    project: projectName,
    branch: (cwd) => {
      const root = findRepoRoot(cwd);
      return root ? readBranch(root) : null;
    },
    head: (cwd) => {
      const root = findRepoRoot(cwd);
      return root ? readHead(root) : null;
    },
    commit: (cwd, sha) => {
      const root = findRepoRoot(cwd);
      return root ? commitInfo(root, sha) : null;
    },
    transcript: readTranscript,
    usage: readUsage,
    context: readContext(input.session_id),
    sendPrompts: config.prompts !== false
  });
  if (plan.sessionChanged) writeSession(plan.session);
  if (plan.context) writeContext(input.session_id, plan.context);
  if (plan.subagentStart) addSubagent(input.session_id, plan.subagentStart);
  if (plan.subagentStop) removeSubagent(input.session_id, plan.subagentStop);
  syncInbox(config, input.session_id, input.hook_event_name, input.permission_mode);
  if (input.hook_event_name === "SessionStart" && process.env.CLAUDE_ENV_FILE) {
    (0, import_node_fs7.appendFileSync)(process.env.CLAUDE_ENV_FILE, `export AGENT_MANAGER_SESSION=${input.session_id}
`);
  }
  if (plan.ensureDaemon) ensureDaemon(scriptPath());
  const timeoutMs = input.hook_event_name === "SessionEnd" ? 1500 : 5e3;
  const results = await Promise.allSettled(plan.reports.map((r) => deliver(config, input.session_id, r, timeoutMs)));
  for (const r of results) {
    if (r.status === "rejected") logLine(`hook ${input.hook_event_name}: ${r.reason.message}`);
  }
}
function findCallingSession() {
  const fromEnv = process.env.AGENT_MANAGER_SESSION;
  if (fromEnv) {
    const s = readSession(fromEnv);
    if (s) return s;
  }
  const chain = ancestors();
  const candidates = listSessions().filter((s) => !s.endedAt && s.pid !== null && chain.includes(s.pid)).sort((a, b) => b.startedAt.localeCompare(a.startedAt));
  if (!candidates[0]) {
    throw new NotFoundError(
      "Could not tell which Claude Code session is calling. Run this from a Claude Code shell after agentctl install, or set AGENT_MANAGER_SESSION."
    );
  }
  return candidates[0];
}
async function reportForSession(s, fields) {
  const config = loadConfig();
  const report = {
    agentId: s.agentId,
    kind: "claude-code",
    machine: config.machine,
    name: s.name,
    project: s.project,
    instructionsVersion: INSTRUCTIONS_VERSION,
    at: (/* @__PURE__ */ new Date()).toISOString(),
    ...fields
  };
  const res = await post(config, "/report", report);
  writeSendState(s.sessionId, s.agentId, { lastSentAt: Date.now(), pendingSeq: "" });
  return res;
}
async function statusCommand(positional, flags) {
  const text2 = positional.join(" ").trim();
  if (!text2) throw new UsageError('Usage: agentctl status "<what you are working on>" [--state working|waiting|idle]');
  const state = flags.state;
  if (state && !REPORTED_STATES.includes(state)) {
    throw new UsageError(`--state must be one of ${REPORTED_STATES.join(", ")}`);
  }
  const s = findCallingSession();
  const res = await reportForSession(s, { activity: text2, ...state ? { state } : {} });
  console.log(`Activity set for ${s.name}: ${res.agentUrl}`);
}
async function pinCommand(field, positional, flags) {
  const clear = "clear" in flags;
  const text2 = positional.join(" ").trim();
  const workType = field === "story" && "type" in flags ? workTypeFlag(flags.type) : void 0;
  if (!text2 && !clear && !workType) {
    throw new UsageError(`Usage: agentctl ${field} "<text>"${field === "story" ? " [--type <kind of work>]" : ""} | agentctl ${field} --clear`);
  }
  const s = findCallingSession();
  let context = readContext(s.sessionId);
  if (text2 || clear) context = { ...context, [field]: clear ? void 0 : text2 };
  if (workType) context = { ...context, workType };
  writeContext(s.sessionId, context);
  const value = clear ? field === "task" ? context.todo ?? null : void 0 : text2 || void 0;
  if (value === void 0 && !workType) {
    console.log(`Story cleared for ${s.name}; the next update works it out again.`);
    return;
  }
  const res = await reportForSession(s, { ...value !== void 0 ? { [field]: value } : {}, ...workType ? { workType } : {} });
  const what = value !== void 0 ? `${field === "story" ? "Story" : "Task"} ${value ? "set" : "cleared"}` : "Work type set";
  console.log(`${what} for ${s.name}${workType ? ` (${workType})` : ""}: ${res.agentUrl}`);
}
function workTypeFlag(value) {
  if (!value || !WORK_TYPES.includes(value)) {
    throw new UsageError(`--type must be one of ${WORK_TYPES.join(", ")}`);
  }
  return value;
}
var UncommittedError = class extends Error {
};
async function doneCommand(positional, flags, lists) {
  let text2 = positional.join(" ").trim();
  if (text2 === "-") text2 = (await readStdin()).trim();
  if (!text2) throw new UsageError('Usage: agentctl done "<what you did>" [--check "<what the person should see>"]... [--title "<name>"]');
  const s = findCallingSession();
  const context = readContext(s.sessionId);
  const root = findRepoRoot(s.cwd);
  if (root && !("uncommitted" in flags) && hasUncommittedChanges(root)) {
    throw new UncommittedError("There are uncommitted changes. Commit the work first (the report links to the commit), or pass --uncommitted.");
  }
  const head = root ? readHead(root) : null;
  const madeNow = head !== null && head !== context.headAtPrompt;
  const commit = root && head && madeNow ? commitInfo(root, head) : null;
  const title = flags.title?.trim() || commit?.subject;
  if (!title) throw new UsageError('No commit since the prompt to take a title from: commit first, or pass --title "<name>"');
  const split = splitChecks(text2);
  const checks = [...lists.check ?? [], ...split.checks];
  const res = await reportForSession(s, {
    result: {
      title,
      summary: split.summary || text2,
      checks,
      commit: commit?.sha ?? null,
      commitUrl: commit?.url ?? null,
      branch: commit?.branch ?? (root ? readBranch(root) : null),
      pushed: commit ? commit.pushed : null
    }
  });
  writeContext(s.sessionId, { ...context, ...head ? { headAtPrompt: head } : {}, reported: true });
  console.log(`Reported "${title}" for ${s.name}: ${res.agentUrl}`);
  if (commit && !commit.pushed) console.log("The commit is not pushed yet: its link works once it is.");
  if (!commit && !("uncommitted" in flags)) console.log("No commit was made during this request, so the report has no commit link.");
}
var StillOpenError = class extends Error {
};
var BLOCKER_ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
var WAIT_POLL_MS = 5e3;
function waitSeconds(flags) {
  if (!("wait" in flags)) return null;
  const n = Number(flags.wait);
  if (!Number.isFinite(n) || n < 0 || n > 86400) throw new UsageError("--wait takes a number of seconds, such as --wait 540");
  return n;
}
async function showBlocker(config, id, seconds) {
  const deadline = Date.now() + (seconds ?? 0) * 1e3;
  for (; ; ) {
    const { blocker } = await get(config, `/blocker?${new URLSearchParams({ id })}`);
    if (blocker.status !== "open") {
      console.log(describeBlocker(blocker));
      return;
    }
    if (Date.now() + WAIT_POLL_MS > deadline) {
      console.log(describeBlocker(blocker));
      if (seconds !== null) throw new StillOpenError(`Still open after ${seconds} s. Check again with: agentctl blocker ${id} --wait <seconds>`);
      return;
    }
    await new Promise((r) => setTimeout(r, WAIT_POLL_MS));
  }
}
async function blockerCommand(positional, flags, lists) {
  const wait = waitSeconds(flags);
  if (positional.length === 1 && BLOCKER_ID.test(positional[0])) {
    await showBlocker(loadConfig(), positional[0], wait);
    return;
  }
  const title = positional.join(" ").trim();
  if (!title) {
    throw new UsageError(`Usage: agentctl blocker "<what's in the way>" [--details "<more>"] [--screenshot <file>] [--screen] [--wait <seconds>]`);
  }
  let details = flags.details?.trim() ?? null;
  if (details === "-") details = (await readStdin()).trim();
  const files = [...lists.screenshot ?? [], ...lists.video ?? []].map(readBlockerFile);
  if ("screen" in flags) files.push(captureScreen());
  const s = findCallingSession();
  const config = loadConfig();
  const res = await post(config, "/blockers", { agentId: s.agentId, title, details: details || null });
  const id = res.stored.id;
  const attached = [];
  const missed = [];
  for (const f of files) {
    try {
      const path = `/blockers/media?${new URLSearchParams({ id, name: f.name })}`;
      await postFile(config, path, f.bytes, f.contentType);
      attached.push(f.name);
    } catch (e) {
      missed.push(`${f.name}: ${e.message}`);
    }
  }
  console.log(`Blocker reported for ${s.name}: ${res.blockerUrl}`);
  console.log(`Id: ${id}`);
  if (attached.length) console.log(`Attached: ${attached.join(", ")}`);
  for (const m of missed) console.log(`Not attached: ${m}`);
  for (const w of res.warnings) console.log(`Note: ${w}`);
  if (wait === null) {
    console.log(`Check for the answer with: agentctl blocker ${id} --wait <seconds>`);
    return;
  }
  await showBlocker(config, id, wait);
}
function readSettings() {
  const file = paths.claudeSettings();
  if (!(0, import_node_fs7.existsSync)(file)) return {};
  try {
    return JSON.parse((0, import_node_fs7.readFileSync)(file, "utf8"));
  } catch (e) {
    throw new ConfigError(`${file} isn't valid JSON (${e.message}); fix it, then run install again`);
  }
}
function writeSettings(settings) {
  const file = paths.claudeSettings();
  let backup = null;
  if ((0, import_node_fs7.existsSync)(file)) {
    backup = `${file}.bak-${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-")}`;
    (0, import_node_fs7.copyFileSync)(file, backup);
  }
  writeJsonFile(file, settings);
  return backup;
}
function userEnvKey() {
  if (process.platform !== "win32") return "";
  try {
    const out = (0, import_node_child_process5.execFileSync)("reg", ["query", "HKCU\\Environment", "/v", "AGENT_MANAGER_KEY"], { encoding: "utf8", windowsHide: true });
    return /AGENT_MANAGER_KEY\s+REG_\w+\s+(\S+)/.exec(out)?.[1] ?? "";
  } catch {
    return "";
  }
}
async function installCommand(flags) {
  const saved = readJsonFile(paths.config());
  const url = (flags.url || process.env.AGENT_MANAGER_URL || saved?.url || "").replace(/\/+$/, "");
  const key = flags.key || process.env.AGENT_MANAGER_KEY || userEnvKey() || saved?.key || "";
  const machine = flags.machine || saved?.machine || defaultMachineName();
  if (!/^https?:\/\//.test(url)) throw new UsageError("Usage: agentctl install --url https://<your Agent Manager Delux> [--key <key>] [--machine <name>]");
  if (!key) throw new UsageError("No machine key: make one on the Settings tab, then set AGENT_MANAGER_KEY or pass --key");
  if ("allow-messages" in flags && "no-messages" in flags) throw new UsageError("Pass --allow-messages or --no-messages, not both");
  const messages = "allow-messages" in flags ? true : "no-messages" in flags ? false : saved?.messages === true;
  const config = {
    url,
    key,
    machine,
    ...saved?.prompts === false ? { prompts: false } : {},
    ...messages ? { messages: true } : {}
  };
  const check = await post(config, "/report", {
    agentId: `${machine}/agentctl`,
    kind: "other",
    machine,
    test: true
  });
  if (!check.ok) throw new SendError("Agent Manager Delux did not accept the test report");
  (0, import_node_fs7.mkdirSync)((0, import_node_path6.dirname)(paths.script()), { recursive: true });
  if ((0, import_node_path6.resolve)(scriptPath()) !== (0, import_node_path6.resolve)(paths.script())) (0, import_node_fs7.copyFileSync)(scriptPath(), paths.script());
  writeJsonFile(paths.config(), config);
  if (!messages) removeAllInboxes();
  const backup = writeSettings(withAgentctlHooks(readSettings(), process.execPath, paths.script()));
  const daemon = readJsonFile(paths.daemon());
  if (daemon && isAlive(daemon.pid)) process.kill(daemon.pid);
  console.log(`Agent Manager Delux reporting is set up for ${machine} (instructions version ${INSTRUCTIONS_VERSION}, ${INSTRUCTIONS_UPDATED}).
  Config:    ${paths.config()}
  agentctl:  ${paths.script()}
  Hooks:     ${paths.claudeSettings()}${backup ? `
  Backup:    ${backup}` : ""}
  Messages:  ${messages ? "on: you can send messages to these sessions from Agent Manager Delux" : "off (--allow-messages turns them on)"}
New Claude Code sessions on this PC now appear at ${url}/agents within a few seconds.
Sessions that are already open start reporting once Claude Code reloads its settings.`);
}
function uninstallCommand() {
  const settings = readSettings();
  const cleaned = withoutAgentctlHooks(settings);
  if (JSON.stringify(cleaned) === JSON.stringify(settings)) {
    console.log("No agentctl hooks found; nothing to remove.");
    return;
  }
  const backup = writeSettings(cleaned);
  const d = readJsonFile(paths.daemon());
  if (d && isAlive(d.pid)) process.kill(d.pid);
  removeAllInboxes();
  console.log(`Removed the agentctl hooks from ${paths.claudeSettings()}${backup ? ` (backup: ${backup})` : ""}.`);
}
async function perfCommand(positional, flags) {
  const config = loadConfig();
  if (positional[0]) {
    const detail = await get(config, `/perf/session?${new URLSearchParams({ id: positional[0] })}`);
    console.log(JSON.stringify(detail, null, 2));
    return;
  }
  const params = new URLSearchParams({ days: flags.days ?? "30", limit: flags.limit ?? "50" });
  if (flags.game) params.set("game", flags.game);
  const list = await get(config, `/perf/sessions?${params}`);
  if (flags.json) {
    console.log(JSON.stringify(list, null, 2));
    return;
  }
  if (list.sessions.length === 0) {
    console.log(`No performance sessions in the last ${list.days} days${flags.game ? ` for ${flags.game}` : ""}.`);
    return;
  }
  const num = (v, unit, digits = 0) => v === null ? "-" : `${v.toFixed(digits)}${unit}`;
  const rows = list.sessions.map((s) => {
    const stats = perfStats(s.totals);
    return [
      s.id,
      `${s.startedAt.slice(0, 16)}Z`,
      s.game,
      s.build ?? "-",
      s.machine,
      s.gpu ?? "-",
      s.resolution ?? "-",
      num(stats.seconds, "s"),
      num(stats.avgFps, " fps"),
      `p99 ${num(stats.frameMsP99, " ms", 1)}`,
      `worst ${num(stats.frameMsMax, " ms", 1)}`,
      `${stats.hitches} hitches`,
      stats.bound ? `${stats.bound}-bound` : "-"
    ];
  });
  const widths = rows[0].map((_, i) => Math.max(...rows.map((r) => r[i].length)));
  for (const r of rows) console.log(r.map((cell, i) => cell.padEnd(widths[i])).join("  ").trimEnd());
  if (list.truncated) console.log(`(more sessions exist; raise --limit or narrow with --game)`);
}
async function testCommand() {
  const config = loadConfig();
  const res = await post(config, "/report", {
    agentId: `${config.machine}/agentctl`,
    kind: "other",
    machine: config.machine,
    activity: "agentctl test",
    test: true
  });
  console.log(`Agent Manager Delux at ${config.url} accepted a test report from ${config.machine}.`);
  if (res.warnings.length) console.log(`Warnings: ${res.warnings.join("; ")}`);
}
async function doctorCommand() {
  const lines = [];
  let config = null;
  try {
    config = loadConfig();
    lines.push(`Config:     ${config.url}, machine ${config.machine}, key ${config.key.slice(0, 13)}\u2026`);
  } catch (e) {
    lines.push(`Config:     ${e.message}`);
  }
  const settings = (() => {
    try {
      return readSettings();
    } catch (e) {
      lines.push(`Hooks:      ${e.message}`);
      return null;
    }
  })();
  if (settings) lines.push(`Hooks:      ${hasAgentctlHooks(settings) ? "installed" : "missing (run agentctl install)"} in ${paths.claudeSettings()}`);
  const d = readJsonFile(paths.daemon());
  lines.push(`Heartbeat:  ${d && isAlive(d.pid) ? `running (pid ${d.pid}, last beat ${d.beatAt})` : "not running (starts with the next session)"}`);
  const live = listSessions().filter((s) => !s.endedAt);
  lines.push(`Sessions:   ${live.length} open${live.map((s) => `
            ${s.name} (pid ${s.pid ?? "?"}${s.pid && !isAlive(s.pid) ? ", gone" : ""})`).join("")}`);
  if (config?.messages) {
    const ready = live.filter((s) => readInbox(s.sessionId)).length;
    lines.push(`Messages:   on; ${ready} of ${live.length} open sessions can take one (the rest after their next hook event)`);
  } else {
    lines.push("Messages:   off (agentctl install --allow-messages turns them on)");
  }
  if (config) {
    try {
      await post(config, "/report", { agentId: `${config.machine}/agentctl`, kind: "other", machine: config.machine, test: true });
      lines.push("Connection: OK");
    } catch (e) {
      lines.push(`Connection: ${e.message}`);
    }
  }
  const log = (0, import_node_fs7.existsSync)(paths.log()) ? (0, import_node_fs7.readFileSync)(paths.log(), "utf8").trim().split("\n").slice(-10) : [];
  lines.push(`Recent log: ${log.length ? `
            ${log.join("\n            ")}` : "empty"}`);
  console.log(lines.join("\n"));
}
async function main(argv) {
  const [command, ...rest] = argv;
  try {
    const { positional, flags, lists } = parseArgs(rest);
    switch (command) {
      case "hook":
        try {
          await hookCommand();
        } catch (e) {
          logLine(`hook: ${e.message}`);
        }
        return 0;
      // a hook never reports failure to Claude Code; the log has it
      case "daemon":
        await runDaemon();
        return 0;
      case "install":
        await installCommand(flags);
        return 0;
      case "uninstall":
        uninstallCommand();
        return 0;
      case "status":
        await statusCommand(positional, flags);
        return 0;
      case "story":
      case "task":
        await pinCommand(command, positional, flags);
        return 0;
      case "done":
        await doneCommand(positional, flags, lists);
        return 0;
      case "blocker":
        await blockerCommand(positional, flags, lists);
        return 0;
      case "perf":
        await perfCommand(positional, flags);
        return 0;
      case "test":
        await testCommand();
        return 0;
      case "doctor":
        await doctorCommand();
        return 0;
      case "version":
        console.log(`agentctl, instructions version ${INSTRUCTIONS_VERSION} (${INSTRUCTIONS_UPDATED})`);
        return 0;
      case void 0:
      case "help":
      case "--help":
      case "-h":
        console.log(HELP);
        return 0;
      default:
        throw new UsageError(`Unknown command "${command}". Run agentctl help.`);
    }
  } catch (e) {
    console.error(`agentctl: ${e.message}`);
    if (e instanceof UsageError) return 1;
    if (e instanceof ConfigError) return 2;
    if (e instanceof NotFoundError) return 3;
    if (e instanceof SendError) return 4;
    if (e instanceof UncommittedError) return 5;
    if (e instanceof StillOpenError) return 6;
    if (e instanceof BlockerFileError) return 1;
    return 1;
  }
}
main(process.argv.slice(2)).then((code) => process.exit(code));
